#!/usr/bin/env bash
export MONGO_DATABASE=reminderDb
export MONGO_USERNAME=chandan
export MONGO_PASSWORD=root
export MONGO_PORT=27017
export MONGO_HOST=localhost